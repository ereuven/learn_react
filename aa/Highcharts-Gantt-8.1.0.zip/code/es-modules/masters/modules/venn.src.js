/**
 * @license Highcharts JS v8.1.0 (2020-05-05)
 * @module highcharts/modules/venn
 * @requires highcharts
 *
 * (c) 2017-2019 Highsoft AS
 * Authors: Jon Arild Nygard
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/venn.src.js';
